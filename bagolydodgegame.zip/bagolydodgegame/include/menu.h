#ifndef MENU_H
#define MENU_H
#include "render.h"
#include "state.h"
#include <stdio.h>
#include <SDL2/SDL.h>
void menu(SDL_Event *e, State *state);
#endif