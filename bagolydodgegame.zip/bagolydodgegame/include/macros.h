#ifndef MACROS_H
#define MACROS_H
#define WINDOWWIDTH 1280
#define WINDOWHEIGHT 960
#endif