#ifndef STATE_H
#define STATE_H
typedef enum State {MENU, GAME, QUIT} State;
#endif