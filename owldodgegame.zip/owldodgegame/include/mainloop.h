#ifndef MAINLOOP_H
#define MAINLOOP_H
#include "state.h"
#include "menu.h"
#include "game.h"
#include <stdio.h>
#include <SDL2/SDL.h>
void loop();
#endif