#ifndef SCOREBOARD_H
#define SCOREBOARD_H
void loadfromfile();
void savetofile();
#endif