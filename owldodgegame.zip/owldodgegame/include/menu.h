#ifndef MENU_H
#define MENU_H
#include <stdio.h>
#include <SDL2/SDL.h>
#include "render.h"
#include "state.h"
#include "math_helper.h"
#include "macros.h"
void menu(SDL_Event *e, State *state);
#endif